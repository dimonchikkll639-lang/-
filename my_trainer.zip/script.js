let globalHistory = [];

// ===== КЛАССИЧЕСКИЙ РЕЖИМ =====
let a, b, op, result;
let correct = 0, wrong = 0, total = 0;
let classicLock = false;
let classicTimer = null;

const exampleEl = document.getElementById('example');
const hintsEl = document.getElementById('visualHints');
const feedbackEl = document.getElementById('feedback');
const answerEl = document.getElementById('answer');
const classicBox = document.getElementById('classicBox');

function randInt(max) { return Math.floor(Math.random() * (max + 1)); }

function generateClassic() {
  op = Math.random() < 0.5 ? '+' : '−';
  if (op === '+') {
    a = randInt(10);
    b = randInt(10 - a);
    result = a + b;
  } else {
    a = randInt(10);
    b = randInt(a);
    result = a - b;
  }
}

function dots(count, cls) {
  let html = '<div class="hint-group">';
  for (let i = 0; i < count; i++) html += `<span class="dot ${cls}"></span>`;
  html += '</div>';
  return html;
}

function renderClassic() {
  exampleEl.innerHTML = `${a} <span style="color:#f5576c">${op}</span> ${b} = <span style="color:#38ef7d">?</span>`;
  let html = '';
  if (op === '+') {
    html = dots(a, 'dot-a') + '<span class="sep">+</span>' + dots(b, 'dot-b');
  } else {
    html = '<div class="hint-group">';
    for (let i = 0; i < a; i++) {
      html += `<span class="dot ${i < b ? 'dot-b' : 'dot-r'}"></span>`;
    }
    html += '</div>';
  }
  hintsEl.innerHTML = html;
}

function newClassicExample() {
  if (classicTimer) clearTimeout(classicTimer);
  classicLock = false;
  classicBox.className = 'example-box';
  generateClassic();
  renderClassic();
  answerEl.value = '';
  answerEl.focus();
  feedbackEl.className = 'feedback';
  feedbackEl.innerHTML = '';
}

function updateClassicStats() {
  document.getElementById('correctCount').textContent = correct;
  document.getElementById('wrongCount').textContent = wrong;
  document.getElementById('totalCount').textContent = total;
  const pct = total > 0 ? Math.round((correct / total) * 100) : 0;
  const bar = document.getElementById('progressBar');
  bar.style.width = pct + '%';
  bar.textContent = pct + '%';
}

function checkAnswer() {
  if (classicLock) return;

  const val = parseInt(answerEl.value, 10);
  if (isNaN(val)) { answerEl.focus(); return; }

  classicLock = true;
  total++;
  const isCorrect = val === result;

  globalHistory.unshift({
    modeTag: 'Пример',
    text: `${a} ${op} ${b} = ${val}`,
    isCorrect: isCorrect,
    correctDetail: isCorrect ? '' : `правильно: ${result}`
  });

  if (isCorrect) {
    correct++;
    feedbackEl.className = 'feedback show correct';
    feedbackEl.innerHTML = '<span class="emoji-bounce">🎉</span> Правильно! Молодец!';
    classicBox.className = 'example-box flash-correct';
  } else {
    wrong++;
    feedbackEl.className = 'feedback show wrong';
    feedbackEl.innerHTML = `<span class="emoji-bounce">🤔</span> Ой! Правильный ответ: ${result}`;
    classicBox.className = 'example-box flash-wrong';
  }

  updateClassicStats();
  classicTimer = setTimeout(() => {
    newClassicExample();
  }, 1200);
}

function resetScore() {
  correct = wrong = total = 0;
  updateClassicStats();
  newClassicExample();
}

answerEl.addEventListener('keydown', e => {
  if (e.key === 'Enter') checkAnswer();
});

// ===== ЧЁТ / НЕЧЁТ РЕЖИМ =====
let eoNumber = 0;
let eoCorrect = 0, eoWrong = 0, eoTotal = 0;
let eoReady = false;
let eoLock = false;

const evenOddView = document.getElementById('evenoddView');
const eoIntro = document.getElementById('evenoddIntro');
const eoGame = document.getElementById('evenoddGame');
const eoNumberEl = document.getElementById('evenoddNumber');
const eoFeedbackEl = document.getElementById('evenoddFeedback');
const eoBox = document.getElementById('evenoddBox');

function generateEvenOdd() {
  let newNum;
  do {
    newNum = randInt(10);
  } while (newNum === eoNumber && eoTotal > 0);
  
  eoNumber = newNum;
  eoNumberEl.textContent = eoNumber;
}

function updateEvenOddStats() {
  document.getElementById('eoCorrect').textContent = eoCorrect;
  document.getElementById('eoWrong').textContent = eoWrong;
  document.getElementById('eoTotal').textContent = eoTotal;
}

function startEvenOddMode() {
  eoIntro.classList.add('hide');
  eoGame.classList.remove('hide');
  eoReady = true;
  eoLock = false;
  eoFeedbackEl.className = 'feedback';
  eoFeedbackEl.innerHTML = '';
  generateEvenOdd();
  updateEvenOddStats();
}

function answerEvenOdd(userSaysEven) {
  if (!eoReady || eoLock) return;

  eoLock = true;
  eoTotal++;
  const isEven = (eoNumber % 2 === 0);
  const correctAnswer = (userSaysEven === isEven);

  globalHistory.unshift({
    modeTag: 'Чёт/Нечёт',
    text: `Число ${eoNumber} → ${userSaysEven ? 'Чётное' : 'Нечётное'}`,
    isCorrect: correctAnswer,
    correctDetail: correctAnswer ? '' : `на самом деле: ${isEven ? 'Чётное' : 'Нечётное'}`
  });

  if (correctAnswer) {
    eoCorrect++;
    eoFeedbackEl.className = 'feedback show correct';
    eoFeedbackEl.innerHTML = '<span class="emoji-bounce">🎉</span> Верно!';
    eoBox.className = 'example-box flash-correct';
  } else {
    eoWrong++;
    eoFeedbackEl.className = 'feedback show wrong';
    eoFeedbackEl.innerHTML = `<span class="emoji-bounce">🤔</span> Неверно! Это ${isEven ? 'чётное' : 'нечётное'}`;
    eoBox.className = 'example-box flash-wrong';
  }

  updateEvenOddStats();

  setTimeout(() => {
    eoBox.className = 'example-box';
    eoFeedbackEl.className = 'feedback';
    eoFeedbackEl.innerHTML = '';
    eoLock = false;
    generateEvenOdd();
  }, 900);
}

function backToClassic() {
  switchMode('classic');
}

function switchMode(mode) {
  const classicBtn = document.getElementById('classicModeBtn');
  const eoBtn = document.getElementById('evenoddModeBtn');

  if (mode === 'classic') {
    document.getElementById('classicView').classList.add('active');
    evenOddView.classList.remove('active');
    classicBtn.classList.add('active');
    eoBtn.classList.remove('active');
    answerEl.focus();
  } else {
    document.getElementById('classicView').classList.remove('active');
    evenOddView.classList.add('active');
    classicBtn.classList.remove('active');
    eoBtn.classList.add('active');
    
    eoIntro.classList.remove('hide');
    eoGame.classList.add('hide');
    eoReady = false;
  }
}

// ===== ЛОГИКА ОКНА ИСТОРИИ =====
function openHistoryModal() {
  const modal = document.getElementById('historyModal');
  const list = document.getElementById('historyList');

  renderHistoryList(globalHistory, list);
  modal.classList.add('active');
}

function closeHistoryModal() {
  document.getElementById('historyModal').classList.remove('active');
}

function renderHistoryList(historyArray, listContainer) {
  if (historyArray.length === 0) {
    listContainer.innerHTML = '<div class="history-empty">Вы пока не решили ни одного задания!</div>';
    return;
  }

  const checkSvg = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg>`;
  const crossSvg = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>`;

  let html = '';
  historyArray.forEach(item => {
    const badgeClass = item.isCorrect ? 'success' : 'error';
    const svgIcon = item.isCorrect ? checkSvg : crossSvg;
    const detail = item.correctDetail ? `<span class="history-detail">(${item.correctDetail})</span>` : '';
    
    html += `
      <div class="history-item">
        <div>
          <span class="history-tag">${item.modeTag}</span>
          <span class="history-text">${item.text}</span>
          ${detail}
        </div>
        <div class="status-icon ${badgeClass}">
          ${svgIcon}
        </div>
      </div>
    `;
  });
  listContainer.innerHTML = html;
}

// Старт
newClassicExample();
